﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace JOY
{
    public partial class Condição3 : Form
    {
        public Condição3()
        {
            InitializeComponent();
        }
    }
}
